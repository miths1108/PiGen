SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 2) AND (t18_c016 <= 4) AND (((t18_c011 >= 6) AND (t18_c011 <= 8)) OR ((t18_c002 >= 18) AND (t18_c002 <= 22)) OR ((t18_c022 >= 16) AND (t18_c022 <= 20)))
;