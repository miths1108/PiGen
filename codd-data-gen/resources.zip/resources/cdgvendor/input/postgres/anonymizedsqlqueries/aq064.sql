SELECT * FROM
    t12
WHERE 1=1 
    AND (t12_c015 >= 10) AND (t12_c015 <= 14)
;