SELECT * FROM
    t07
WHERE 1=1 
    AND (t07_c027 = 8) AND (t07_c019 = 16) AND (t07_c009 = 8)
;