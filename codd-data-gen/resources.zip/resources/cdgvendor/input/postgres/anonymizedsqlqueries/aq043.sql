SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 22) AND (t18_c016 <= 24) AND (((t18_c011 >= 12) AND (t18_c011 <= 16)) OR ((t18_c002 >= 10) AND (t18_c002 <= 12)) OR ((t18_c022 >= 12) AND (t18_c022 <= 18)))
;