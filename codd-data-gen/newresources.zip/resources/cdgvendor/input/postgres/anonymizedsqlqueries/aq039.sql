SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 6) AND (t18_c016 <= 8) AND (((t18_c011 >= 18) AND (t18_c011 <= 20)) OR ((t18_c002 >= 2) AND (t18_c002 <= 6)) OR ((t18_c022 >= 22) AND (t18_c022 <= 24)))
;