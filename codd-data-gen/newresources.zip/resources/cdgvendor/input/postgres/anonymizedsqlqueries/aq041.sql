SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 14) AND (t18_c016 <= 16) AND (((t18_c011 >= 2) AND (t18_c011 <= 4)) OR ((t18_c002 >= 20) AND (t18_c002 <= 24)) OR ((t18_c022 >= 2) AND (t18_c022 <= 8)))
;