SELECT * FROM
    t07
WHERE 1=1 
    AND (t07_c027 = 2) AND (t07_c019 = 8)
;