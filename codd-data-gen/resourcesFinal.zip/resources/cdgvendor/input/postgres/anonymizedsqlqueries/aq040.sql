SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 10) AND (t18_c016 <= 12) AND (((t18_c011 >= 10) AND (t18_c011 <= 14)) OR ((t18_c002 >= 14) AND (t18_c002 <= 16)) OR ((t18_c022 >= 6) AND (t18_c022 <= 14)))
;