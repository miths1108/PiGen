SELECT * FROM
    t04,
    t05
WHERE 1=1 
    AND t04_F_t05 = t05_P
    AND t04_c016 = 2
;