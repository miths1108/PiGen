SELECT * FROM
    t18
WHERE 1=1 
    AND (t18_c016 >= 18) AND (t18_c016 <= 20) AND (((t18_c011 >= 22) AND (t18_c011 <= 24)) OR ((t18_c002 >= 4) AND (t18_c002 <= 8)) OR ((t18_c022 >= 4) AND (t18_c022 <= 10)))
;