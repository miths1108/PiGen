SELECT * FROM
    t12
WHERE 1=1 
    AND (t12_c006 = 2) OR (t12_c006 = 14) OR (t12_c006 = 12)
;