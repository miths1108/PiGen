select distinct ca_zip
 from catalog_sales, customer, customer_address, date_dim
 where cs_bill_customer_sk = c_customer_sk
 	and c_current_addr_sk = ca_address_sk 
 	and cs_sales_price > 500
 	and cs_sold_date_sk = d_date_sk
 	and d_qoy = 2 and d_year = 1998
 ;


